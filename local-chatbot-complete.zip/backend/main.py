from fastapi import FastAPI, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
import shutil
import os
import subprocess
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.docstore.document import Document

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Initialize FAISS store
vector_store = None

@app.post("/upload/")
async def upload_files(files: list[UploadFile] = File(...)):
    global vector_store
    saved_files = []
    docs = []
    for file in files:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        saved_files.append(file.filename)
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
            docs.append(Document(page_content=content))

    # Split text into chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=2000, chunk_overlap=200)
    split_docs = splitter.split_documents(docs)

    # Create embeddings and store in FAISS
    embeddings = OpenAIEmbeddings(openai_api_key="sk-REPLACE_WITH_KEY")
    vector_store = FAISS.from_documents(split_docs, embeddings)

    return {"status": "success", "files": saved_files}

@app.post("/ask/")
async def ask_question(question: str):
    global vector_store
    if not vector_store:
        return {"answer": "No documents uploaded yet."}

    # Retrieve relevant chunks
    docs = vector_store.similarity_search(question, k=3)
    context = "
".join([d.page_content for d in docs])

    # Call Ollama model locally with context
    prompt = f"Context:
{context}

Question: {question}
Answer:"
    cmd = ["ollama", "run", "codellama", prompt]
    result = subprocess.run(cmd, capture_output=True, text=True)
    return {"answer": result.stdout}
