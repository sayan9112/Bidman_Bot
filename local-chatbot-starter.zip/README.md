# Local AI Chatbot

## Overview
This project provides a local AI chatbot that analyzes large codebases and answers questions using a local LLM (Code Llama via Ollama).

### Features
- Upload multiple files
- Ask coding questions
- Runs completely offline

### Setup
1. Install Python 3.10+
2. Install Node.js and Angular CLI
3. Install Ollama and pull Code Llama model:
   ```bash
   ollama pull codellama
   ```
4. Backend:
   ```bash
   cd backend
   pip install -r requirements.txt
   uvicorn main:app --reload
   ```
5. Frontend:
   ```bash
   cd frontend
   ng serve
   ```
